package feedback_user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

class UserFeedback {
    private String name;
    private String email;

    public UserFeedback(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
}

class Feedback extends UserFeedback {
    private int roomRate;
    private int foodRate;
    private String feedbackText;

    public Feedback(String name, String email, int roomRate, int foodRate, String feedbackText) {
        super(name, email);
        this.roomRate = roomRate;
        this.foodRate = foodRate;
        this.feedbackText = feedbackText;
    }

    public int getRoomRate() {
        return roomRate;
    }

    public int getFoodRate() {
        return foodRate;
    }

    public String getFeedbackText() {
        return feedbackText;
    }
}

public class feedbackForm {

    private static final String DB_URL = "jdbc:mysql://localhost/hotelfeedback";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Kishore@2004";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter your name:");
        String name = sc.nextLine();
        System.out.println("Please enter your Email:");
        String email = sc.nextLine();
        System.out.println("Please enter your Rooms_Rating:");
        int roomRate = sc.nextInt();
        System.out.println("Please enter your Food_Rating:");
        int foodRate = sc.nextInt();
        sc.nextLine(); // Consume the newline character
        System.out.println("Share details of your own Experience at this place:");
        String feedbackText = sc.nextLine();

        Feedback feedback = new Feedback(name, email, roomRate, foodRate, feedbackText);
        saveFeedbackToDatabase(feedback);
    }

    private static void saveFeedbackToDatabase(Feedback feedback) {
        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO feedback (Name, Email, roomRate, Foodrate, feedbackText) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, feedback.getName());
            preparedStatement.setString(2, feedback.getEmail());
            preparedStatement.setInt(3, feedback.getRoomRate());
            preparedStatement.setInt(4, feedback.getFoodRate());
            preparedStatement.setString(5, feedback.getFeedbackText());
            preparedStatement.executeUpdate();
            System.out.println("Feedback saved successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

/**
 * 
 */
/**
 * @author ASUS
 *
 */
module Feedback {
	requires java.sql;
}